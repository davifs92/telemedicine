package com.example.shared_libs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SharedLibsApplicationTests {

	@Test
	void contextLoads() {
	}

}
